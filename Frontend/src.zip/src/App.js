
import './App.css';
import Login from './comp/Login';
import AllRoutes from './components/AllRoutes/AllRoutes';
import Navbar from './components/Navbar/Navbar';
import NavofProject from './components/Project/NavofProject';





function App() {
  return (
    <div className="App">
       {/* <Navbar/> */}
         {/* <AllRoutes/> */}
       {/* <MainHome/> */}
     <NavofProject />
    
    </div>
  );
}

export default App;
